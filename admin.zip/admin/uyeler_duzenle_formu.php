 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Üye Düzenleme
                        </div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Üye Düzenleme</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Üyeler Düzenleme</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">

                        <div class="panel panel-yellow">
                                            <div class="panel-heading">
                                                Üye Bilgilerini Giriniz
                                            </div>
                                            <div class="panel-body pan">


                                                <form class="form-horizontal" method="post" action="<?=base_url()?>admin/uyeler/guncelle/<?=$veri[0]->Id?>">
                                                <div class="form-body pal">
                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Adı Soyadı</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="adsoy" value="<?=$veri[0]->adsoy?>" placeholder="Adı Soyadı" class="form-control"></div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Email</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="email" name="email" value="<?=$veri[0]->email?>" placeholder="Email" class="form-control"></div>
                                                        </div>
                                                    </div>


                                                    <div class="form-group">
                                                        <label for="inputPassword" class="col-md-3 control-label">
                                                            Şifre</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-lock"></i>
                                                                <input id="inputPassword" required type="password" name="sifre" value="<?=$veri[0]->sifre?>" placeholder="Şifre" class="form-control">
                                                            </div>
                                                           
                                                        </div>
                                                    </div>


                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Telefon</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="tel" name="tel" value="<?=$veri[0]->tel?>" placeholder="Telefon" class="form-control"></div>
                                                        </div>
                                                    </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Adres</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="adres" value="<?=$veri[0]->adres?>" placeholder="Adres" class="form-control"></div>
                                                        </div>
                                                    </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Şehir</label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="sehir" value="<?=$veri[0]->sehir?>">
                                                                <option>Antalya</option>
                                                                <option>Ankara</option>
                                                                <option>İstanbul</option>
                                                                <option>İzmir</option>
                                                                <option>Bolu</option>
                                                                <option>Bursa</option>
                                                                <option>Muğla</option>
                                                            </select>

                                                        </div>
                                                    </div>



                                                   <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Yetki</label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="yetki" >
                                                                <option><?=$veri[0]->yetki?></option>
                                                                <option>Üye</option>
                                                                <option>Admin</option>
                                                                
                                                            </select>

                                                        </div>
                                                    </div>


                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Durum</label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="durum" >
                                                                <option><?=$veri[0]->durum?></option>
                                                                <option>Aktif</option>
                                                                <option>Pasif</option>
                                                            </select>

                                                        </div>
                                                    </div>


                                                </div>
                                                <div class="form-actions pal">
                                                    <div class="form-group mbn">
                                                        <div class="col-md-offset-3 col-md-6">
                                                            

                                                            <button type="submit" class="btn btn-primary">
                                                                Güncelle</button>

                                                                
                                                        </div>
                                                    </div>
                                                </div>
                                                </form>


                                            </div>
                                        </div>
                    </div>
                </div>
                </div>
            </div>
                      
                <!--END CONTENT-->
<?php 
    $this->load->view('admin/_footer');
?>
