 <!--BEGIN FOOTER-->
                <div id="footer">
                    
                </div>
                <!--END FOOTER-->
            </div>
            <!--END PAGE WRAPPER-->
        </div>
    </div>
    <script src="<?=base_url()?>assets/admin/script/jquery-1.10.2.min.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery-ui.js"></script>
    <script src="<?=base_url()?>assets/admin/script/bootstrap.min.js"></script>
    <script src="<?=base_url()?>assets/admin/script/bootstrap-hover-dropdown.js"></script>
    <script src="<?=base_url()?>assets/admin/script/html5shiv.js"></script>
    <script src="<?=base_url()?>assets/admin/script/respond.min.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.metisMenu.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.slimscroll.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.cookie.js"></script>
    <script src="<?=base_url()?>assets/admin/script/icheck.min.js"></script>
    <script src="<?=base_url()?>assets/admin/script/custom.min.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.news-ticker.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.menu.js"></script>
    <script src="<?=base_url()?>assets/admin/script/pace.min.js"></script>
    <script src="<?=base_url()?>assets/admin/script/holder.js"></script>
    <script src="<?=base_url()?>assets/admin/script/responsive-tabs.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.flot.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.flot.categories.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.flot.pie.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.flot.tooltip.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.flot.resize.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.flot.fillbetween.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.flot.stack.js"></script>
    <script src="<?=base_url()?>assets/admin/script/jquery.flot.spline.js"></script>
    <script src="<?=base_url()?>assets/admin/script/zabuto_calendar.min.js"></script>
    <script src="<?=base_url()?>assets/admin/script/index.js"></script>
    <!--LOADING SCRIPTS FOR CHARTS-->
    <script src="<?=base_url()?>assets/admin/script/highcharts.js"></script>
    <script src="<?=base_url()?>assets/admin/script/data.js"></script>
    <script src="<?=base_url()?>assets/admin/script/drilldown.js"></script>
    <script src="<?=base_url()?>assets/admin/script/exporting.js"></script>
    <script src="<?=base_url()?>assets/admin/script/highcharts-more.js"></script>
    <script src="<?=base_url()?>assets/admin/script/charts-highchart-pie.js"></script>
    <script src="<?=base_url()?>assets/admin/script/charts-highchart-more.js"></script>
    <!--CORE JAVASCRIPT-->
    <script src="<?=base_url()?>assets/admin/script/main.js"></script>
    <script>        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
        ga('create', 'UA-145464-12', 'auto');
        ga('send', 'pageview');


</script>


<!--Koddostu Yılbaşı Ağacı Kodu START
<script>var hirsizalarmi=0;</script><style type="text/css">div.koddostu-yilbasi{position:fixed;text-align:center;z-index:9800;}div.yeniyil-koddostu{bottom:-10px;right:0px;width:256px;height:256px;background:transparent url(http://2.bp.blogspot.com/-dZ_cG3TjSLA/UNyA_jC_Z3I/AAAAAAAARMg/uUH4VPnFwgw/s1600/KODDOSTU.png) no-repeat top left;}</style><style type="text/css">.yeniyil,.yilbasi{display:none !important;} div.koddostu-yilbasi{_position:absolute;}div.yeniyil-koddostu{_bottom:auto;_top:expression(ie6=(document.documentElement.scrollTop+document.documentElement.clientHeight - 52+"px") );}</style><div onclick="hirsizalarmi=hirsizalarmi+1;if(hirsizalarmi == 3){window.open('ht'+'tp:/'+'/w'+'ww.'+'k'+'oddostu.'+'c'+'om/2012/12/ylbas-agac-kodu'+'.'+'h'+'tml','')}" class="koddostu-yilbasi yeniyil-koddostu"></div>
<!--
<script src="https://www.koddostu.com/duzelt.js?no=189"></script> -->


</body>
</html>