 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Mesajlar
                        </div>

                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Mesajlar</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Mesaj Listesi</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                 <div class="panel panel-cream">
                            <div class="panel-heading">
                               <br>
                            </div>

                            <center><i><b><h2>Mesaj Detay Bilgileri</h2></b></i></center>
                    <?php if ($this->session->flashdata("mesaj"))
                    { ?>
                        <div class="alert alert-success">
                            <strong><?=$this->session->flashdata("mesaj")?></strong>
                            <a href="#" class="alert-link"></a>
                        </div>
                     <?php
                     }
                    ?>
                            <div class="panel-body ">
                                <table class="table table-hover table-bordered">
                                    <thead>
                                   
                                    <tr>
                                        <th  class="col-xs-3">Adı Soyadı</th>
                                        <td><?=$veri[0]->adsoy?></td>
                                    </tr>
                                    <tr>
                                        <th>Email</th>
                                        <td><?=$veri[0]->email?></td>
                                    </tr>
                                    <tr>
                                        <th>Telefon</th>
                                        <td><?=$veri[0]->tel?></td>
                                    </tr>
                                    <tr>
                                        <th>Mesaj</th>
                                         <td><?=$veri[0]->mesaj?></td>
                                    </tr>
                                    <tr>
                                        <th>Tarih</th>
                                        <td><?=$veri[0]->tarih?></td>
                                    </tr>
                                        <th>Notunuz</th>
                                        <th>Sil</th>
                                    </tr>
                                    </thead>
                                        <td><center>
                                            <form action="<?=base_url()?>admin/Web_mesajlar/guncelle/<?=$veri[0]->Id?>" method="post">

                                            <textarea name="adminnotu" row="10" cols="60"><?=$veri[0]->adminnotu?></textarea><br>
                                            <input type="submit" value="GUNCELLE" name="guncelle" />
                                        </form>
                                            <center>
                                        </td>
                                        <td><center><a href="<?=base_url()?>admin/Web_mesajlar/sil/<?=$veri[0]->Id?>"  onclick="return confirm('Silinsin mi?')"  class="btn btn-red navbar-btn"><i class="fa fa-trash-o">&nbsp;&nbsp;</i>Sil</a></center></td>
                                    </tr>


                                    </tbody>
                                   
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!--END CONTENT-->
<?php
    $this->load->view('admin/_footer');
?>
