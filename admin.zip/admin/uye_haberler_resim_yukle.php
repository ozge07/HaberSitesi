 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');

        
?>
            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Haber Resim Ekleme
                        </div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Haber Resim Ekleme</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Haber Resim Ekleme</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">

                        <div class="panel panel-yellow">
                                            <div class="panel-heading">
                                                Eklenecek Resim Seçiniz
                                            </div>
                                            <div class="panel-body pan"><br>
                                                &nbsp;&nbsp;*Yüklenecek resim dosyası türleri (gif | jpg | png) max boyutlar : 1024x1024 ,boyut : 1000kb
                                                <?php if ($this->session->flashdata("mesaj")) { ?>
                                        <div class="alert alert-warning alert-dismissable">
                                            <h4>Hata!</h4>
                                            <button type="button" data-dismiss="alert" aria-hidden="true" class="close">×</button>
                                            <strong><?=$this->session->flashdata("mesaj")?></strong>
                                        </div>
                                        <?php } ?>
                                                <form class="form-horizontal" method="post" enctype="multipart/form-data" action="<?=base_url()?>admin/uye_haber/resim_kaydet/<?=$id?>">
                                                <div class="form-body pal">
                                                    <div class="form-group">
                                                        
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="file" name="resim" placeholder="Yükleme için gözat" class="form-control"></div>
                                                        </div>
                                                    </div>

                                                    

                                                </div>
                                                <div class="form-actions pal">
                                                    <div class="form-group mbn">
                                                        <div class="col-md-offset-3 col-md-6">
                                                        

                                                            <button type="submit" class="btn btn-primary">
                                                                Resmi yükle</button>                         
                                                        </div>
                                                    </div>
                                                </div>
                                                </form>

                                            </div>
                                             <center><img src="<?=base_url()?>uploads/<?=$veri[0]->resim?>" height="100"/></center>
                                                </form>
                                        </div>

                    </div>
                </div>
                </div>
            </div>
                      
                <!--END CONTENT-->
<?php 
    $this->load->view('admin/_footer');
?>
