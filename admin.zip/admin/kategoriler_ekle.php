 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
<script src="//cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Kategori Ekleme
                          
                        </div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Kategori Ekleme</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Kategori Ekleme</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">

                        <div class="panel panel-yellow">
                                            <div class="panel-heading">
                                                Kategori Bilgilerini Giriniz
                                            </div>
                                    <div class="panel-body pan">
                                        <form class="form-horizontal" method="post" action="<?=base_url()?>admin/kategoriler/ekle_kaydet">
                                            <div class="form-body pal">
                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Kategori Adı
                                                        </label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="adi" placeholder="Kategori adı" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Description
                                                        </label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="description" placeholder="Description" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Keywords
                                                        </label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="keywords" placeholder="Keywords" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>

                                                <div class="form-actions pal">
                                                    <div class="form-group mbn">
                                                        <div class="col-md-offset-3 col-md-6">
                                                            <button type="submit" class="btn btn-primary">
                                                                Kaydet
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>

                                            </form>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        

                <!--END CONTENT-->
<?php
    $this->load->view('admin/_footer');
?>
<script src="<?=base_url()?>assets/admin/ckeditor/ckeditor.js"></script>
<!--Bootstrap WYSIHTML5 -->
<script src="<?=base_url()?>assets/admin/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script src="<?=base_url()?>assets/admin/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script src="<?=base_url()?>assets/admin/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script>
    $(function (){
        CKEDITOR.replace('aciklama')
        $('.textarea').wysihtml5()
    })
</script>
