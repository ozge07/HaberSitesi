 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
<script src="//cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
                    <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Ayarlar</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="dashboard.html">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Ayarlar</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Ayarlar</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                 <?php if ($this->session->flashdata("mesaj")) 
                    { ?>
                        <div class="alert alert-success">
                            <strong><?=$this->session->flashdata("mesaj")?></strong>
                            <a href="#" class="alert-link"></a>
                        </div>
                     <?php
                     }
                    ?>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">
                        <div class="row mbl">
                            <div class="col-lg-12">
                                
                                            <div class="col-md-12">
                                                <div id="area-chart-spline" style="width: 100%; height: 300px; display: none; padding: 0px; position: relative;">
                                                <canvas class="flot-base" width="1536" height="375" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 1229px; height: 300px;"></canvas><div class="flot-text" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; font-size: smaller; color: rgb(84, 84, 84);"><div class="flot-x-axis flot-x1-axis xAxis x1Axis" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; display: block;"><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 10px;">Jan</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 212px;">Feb</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 413px;">Mar</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 615px;">Apr</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 816px;">May</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 1018px;">Jun</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 1219px;">Jul</div></div><div class="flot-y-axis flot-y1-axis yAxis y1Axis" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; display: block;"><div class="flot-tick-label tickLabel" style="position: absolute; top: 290px; left: 1px;">0</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 250px; left: 1px;">25</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 210px; left: 1px;">50</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 170px; left: 1px;">75</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 130px; left: 1px;">100</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 90px; left: 1px;">125</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 50px; left: 1px;">150</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 10px; left: 1px;">175</div></div></div><canvas class="flot-overlay" width="1536" height="375" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 1229px; height: 300px;"></canvas><div class="legend"><div style="position: absolute; width: 0px; height: 0px; top: 15px; right: 15px; background-color: rgb(255, 255, 255); opacity: 0.85;"> </div><table style="position:absolute;top:15px;right:15px;;font-size:smaller;color:#545454"><tbody><tr><td class="legendColorBox"><div style="border:1px solid #ccc;padding:1px"><div style="width:4px;height:0;border:5px solid #ffce54;overflow:hidden"></div></div></td><td class="legendLabel">Upload</td></tr><tr><td class="legendColorBox"><div style="border:1px solid #ccc;padding:1px"><div style="width:4px;height:0;border:5px solid #01b6ad;overflow:hidden"></div></div></td><td class="legendLabel">Download</td></tr></tbody></table></div></div>
                                            </div>
                                
                            </div>

                            <div class="col-lg-12">
                              
                                    
                              <div class="row">
                    <div class="col-md-12">

                        <div class="row mtl">
                            
                            <div class="col-md-9">
                                <ul class="nav nav-tabs">
                                 
                                    <li class="active"><a href="#genel" data-toggle="tab">Genel</a></li>
                                    <li class=""><a href="#email" data-toggle="tab">Email</a></li>
                                    <li class=""><a href="#sosyal" data-toggle="tab">Sosyal</a></li>
                                    <li class=""><a href="#hakkimizda" data-toggle="tab">Hakkımızda</a></li>
                                    <li class=""><a href="#iletisim" data-toggle="tab">İletişim</a></li>
                                </ul>
                                <form method="post" action="<?=base_url()?>admin/home/ayarlar_guncelle/<?=$veri[0]->Id?>" class="form-horizontal">
                                <div id="generalTabContent" class="tab-content">
                                    <div id="genel" class="tab-pane fade in active">
                                        <h4>Genel Ayarlar</h4>
                                        <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Adı</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="adi" value="<?=$veri[0]->adi?>" class="form-control" id="inputName" placeholder="Name">
                                            </div>
                                        </div>

                                            <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Description</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="description" value="<?=$veri[0]->description?>" class="form-control" id="inputName" placeholder="Description">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Keywords</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="keywords" value="<?=$veri[0]->keywords?>" class="form-control" id="inputName" placeholder="Keywords">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Adres</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="adres" value="<?=$veri[0]->adres?>" class="form-control" id="inputName" placeholder="Adres">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Telefon</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="tel" value="<?=$veri[0]->tel?>" class="form-control" id="inputName" placeholder="Telefon">
                                            </div>
                                        </div>
                                         <div class="form-group">
                                                        <label for="inputName" class="col-md-2 control-label">
                                                            Şehir</label>
                                                        <div class="col-md-10">
                                                            <select class="form-control" required name="sehir">
                                                                <option><?=$veri[0]->sehir?></option>
                                                                <option>Antalya</option>
                                                                <option>Ankara</option>
                                                                <option>İstanbul</option>
                                                                <option>İzmir</option>
                                                                <option>Bolu</option>
                                                                <option>Bursa</option>
                                                                <option>Karabük</option>
                                                            </select>

                                                        </div>
                                                    </div></div>
                                            <hr>
                                             <div id="email" class="tab-pane fade in">
                                        <h4>Email Ayarları</h4>
                                        <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Smtp Server</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="smtpserver" value="<?=$veri[0]->smtpserver?>" class="form-control" id="inputName" placeholder="Smtp Server">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Smtp Email</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="smtpemail" value="<?=$veri[0]->smtpemail?>" class="form-control" id="inputName" placeholder="Smtp Email">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Smtp Port</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="smtpport" value="<?=$veri[0]->smtpport?>" class="form-control" id="inputName" placeholder="Smtp Port">
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Şifre</label>
                                            <div class="col-sm-10">
                                                <input type="password" name="sifre" value="<?=$veri[0]->sifre?>" class="form-control" id="inputName" placeholder="Şifre">
                                            </div>
                                        </div>
                                    </div>

                                        <div id="sosyal" class="tab-pane fade in">
                                        <h4>Sosyal Medya Ayarları</h4>
                                        <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Facebook</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="facebook" value="<?=$veri[0]->facebook?>" class="form-control" id="inputName" placeholder="Facebook">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">İnstagram</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="instagram" value="<?=$veri[0]->instagram?>" class="form-control" id="inputName" placeholder="İnstagram">
                                            </div>
                                        </div>
                                            <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Twitter</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="twitter" value="<?=$veri[0]->twitter?>" class="form-control" id="inputName" placeholder="Twitter">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="inputName" class="col-sm-2 control-label">Pinterest</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="pinterest" value="<?=$veri[0]->pinterest?>" class="form-control" id="inputName" placeholder="Pinterest">
                                            </div>
                                        </div>
                                    </div>

                                        <div id="hakkimizda" class="tab-pane fade in">
                                        <h4>Hakkımızda</h4>
                                        <textarea name="editor1" id="editor1" rows="50" cols="90"><?=$veri[0]->hakkimizda?> </textarea>
                                        <script>
                                            CKEDITOR.replace('editor1');
                                        </script>
                                    </div>

                                    <div id="iletisim" class="tab-pane fade in">
                                        <h4>İletişim Ayarları</h4>
                                         <textarea name="editor2" id="editor2" rows="15" cols="80"><?=$veri[0]->iletisim?>
                                        </textarea>
                                        <script>
                                            CKEDITOR.replace('editor2');
                                        </script>
                                    </div>

                               <div class="row">
                                        <div class="form-group">
                                            <div class="col-sm-offset-2 col-sm-10">
                                                <button type="submit" class="btn btn-danger">Guncelle</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>

                <!--END CONTENT-->
                <?php 
    $this->load->view('admin/_footer');
?>
