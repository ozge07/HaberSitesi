 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Üye Ekleme
                        </div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Üye Ekleme</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Üyeler Ekleme</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">

                        <div class="panel panel-yellow">
                                            <div class="panel-heading">
                                                Üye Bilgilerini Giriniz
                                            </div>
                                            <div class="panel-body pan">
                                                <form class="form-horizontal" method="post" action="<?=base_url()?>admin/uyeler/ekle_kaydet">
                                                <div class="form-body pal">
                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Adı Soyadı</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="adsoy" placeholder="Adı Soyadı" class="form-control"></div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Email</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="email" name="email" placeholder="Email" class="form-control"></div>
                                                        </div>
                                                    </div>


                                                    <div class="form-group">
                                                        <label for="inputPassword" class="col-md-3 control-label">
                                                            Şifre</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-lock"></i>
                                                                <input id="inputPassword" required type="password" name="sifre" placeholder="Şifre" class="form-control">
                                                            </div>
                                                           
                                                        </div>
                                                    </div>


                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Telefon</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="tel" placeholder="Telefon" class="form-control"></div>
                                                        </div>
                                                    </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Adres</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="adres" placeholder="Adres" class="form-control"></div>
                                                        </div>
                                                    </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Şehir</label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="sehir">
                                                                <option>Antalya</option>
                                                                <option>Ankara</option>
                                                                <option>İstanbul</option>
                                                                <option>İzmir</option>
                                                                <option>Bolu</option>
                                                                <option>Bursa</option>
                                                                <option>Muğla</option>
                                                            </select>

                                                        </div>
                                                    </div>



                                                   <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Yetki</label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="yetki">
                                                                <option>Üye</option>
                                                                <option>Admin</option>
                                                                
                                                            </select>

                                                        </div>
                                                    </div>


                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Durum</label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="durum">
                                                                <option>Aktif</option>
                                                                <option>Pasif</option>
                                                            </select>

                                                        </div>
                                                    </div>


                                                </div>
                                                <div class="form-actions pal">
                                                    <div class="form-group mbn">
                                                        <div class="col-md-offset-3 col-md-6">
                                                            <button type="submit" class="btn btn-primary">
                                                                Kaydet</button>   
                                                        </div>
                                                    </div>
                                                </div>
                                                </form>
                                            </div>
                                          </div>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                      
                
<?php 
    $this->load->view('admin/_footer');
?>
