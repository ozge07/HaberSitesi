<!DOCTYPE html>
<html lang="en">
<head>
    <title>AdminPanel | Giriş</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,800italic,400,700,800">
    <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/admin/http://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/admin/styles/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/admin/styles/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/admin/styles/animate.css">
    <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/admin/styles/all.css">
    <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/admin/styles/main.css">
    <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/admin/styles/style-responsive.css">
</head>
<body style="background: url('<?=base_url()?>assets/admin/images/bg/bg.png') center center fixed;">
    <div class="page-form">
        <div class="panel panel-blue">
            <div class="panel-body pan">


                <form action="<?=base_url()?>admin/login/login_ol" method="post" class="form-horizontal">
                <div class="form-body pal">
                    <div class="col-md-12 text-center">
                        <h1 style="margin-top: -90px; font-size: 48px;">
                            Admin</b>Panel</h1></b>
                        <br />
                    </div>
                    <div class="form-group">
                        <div class="col-md-3">
                            <img src="<?=base_url()?>assets/admin/images/avatar/profile-pic.png" class="img-responsive" style="margin-top: -35px;" />
                        </div>
                        <div class="col-md-9 text-center">
                            <?php if ($this->session->flashdata("mesaj"))
                                { ?>
                            <div class="alert alert-danger">
                                <h4>Hata!</h4>
                                <strong><?=$this->session->flashdata("mesaj")?></strong> 
                                <a href="#" class="alert-link"></a>
                            </div>
                            <?php 
                            } ?>
                           
                            <h1>
                                Oturum açmak için giriş yapınız.</h1>
                            <br />
                           
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="inputName" class="col-md-3 control-label">
                            Email:</label>
                        <div class="col-md-9">
                            <div class="input-icon right">
                                <i class="fa fa-user"></i>
                                <input id="inputName" type="email" name="email" required placeholder="Email" class="form-control" /></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword" class="col-md-3 control-label">
                            Şifre:</label>
                        <div class="col-md-9">
                            <div class="input-icon right">
                                <i class="fa fa-lock"></i>
                                <input id="inputPassword" type="password" name="sifre" required placeholder="Şifre" class="form-control" /></div>
                        </div>
                    </div>
                    <div class="form-group mbn">
                        <div class="col-lg-12" align="right">
                            <div class="form-group mbn">
                                <div class="col-lg-3">
                                    &nbsp;
                                </div>
                                <div class="col-lg-9">
                                   
                                    <center><button type="submit" class="btn btn-default">
                                        Giriş Yap</button></center>
                                </div>
                                <div class="col-lg-12 text-center">
                                 
                                  </div>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
                 <div class="social-auth-links text-center">
                    <p> -OR-</p>
                        <a href="#" class="btn btn-block btn-social btn-facebook btn-flat"><i class="fa fa-facebook"></i>Facebook ile oturum aç
                    </a>
                        <a href="#" class="btn btn-block btn-social btn-google btn-flat"><i class="fa fa-google-plus"></i>Google+ ile oturum aç
                    </a>
                </div><br><br>
                <!--/.social-auth-links -->
                 <div class="col-lg-12 text-center">
                         <p>
                             <label>
                                 <a href="#">Şifremi Unuttum</a><br>
                             </label>
                         </p>
                 </div>
                 <div class="col-lg-12 text-center">
                        <p>
                              <label>
                                 <a href="register.html" class="text-center">Yeni Kayıt Oluştur</a>
                             </label>
                         </p>
                 </div>
            </div>
        </div>
</body>
</html>
