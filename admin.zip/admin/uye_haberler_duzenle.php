 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
<script src="//cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Haber Düzenleme
                        </div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Haber Düzenleme</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Haberler Düzenleme</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">

                        <div class="panel panel-yellow">
                                            <div class="panel-heading">
                                                Haber Bilgilerini Giriniz
                                            </div>
                                            <div class="panel-body pan">


                                                <form class="form-horizontal" method="post" action="<?=base_url()?>admin/uye_haber/haber_guncelle/<?=$veri[0]->Id?>">
                                                <div class="form-body pal">
                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Adı
                                                        </label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="adi" value="<?=$veri[0]->adi?>" placeholder="haber adı" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div class="form-group">
                                                        <label for="inputPassword" class="col-md-3 control-label">
                                                            Kategori</label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="kategori" >
                                                                <option value="<?=$veri[0]->kategori?>"><?=$veri[0]->katadi?></option>
                                                                

                                                            <?php foreach($veriler as $rs) { ?>

                                                                <option value="<?=$rs->Id?>"><?=$rs->adi?></option>
                                                            <?php } ?>
                                                                
                                                            </select>
                                                           
                                                        </div>
                                                    </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            description
                                                        </label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="description" value="<?=$veri[0]->description?>" placeholder="description" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>


                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Açıklama</label>
                                                        <div class="col-md-9">
                                                            <textarea name="aciklama" id="editor1"  rows=10 cols=100><?=$veri[0]->aciklama?></textarea>
                                                            <script>
                                                                 // Replace the <textarea id="editor1"> with a CKEditor
                                                                 // instance, using default configuration.
                                                                  CKEDITOR.replace( 'editor1' );
                                                             </script>
                                                    </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Keywords</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="keywords" value="<?=$veri[0]->keywords?>" placeholder="Keywords" class="form-control"></div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Durum</label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="durum" >
                                                                <option><?=$veri[0]->durum?></option>
                                                                <option>onaylandi</option>
                                                                <option>reddedildi</option>
                                                            </select>

                                                        </div>
                                                    </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Grubu</label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="grubu" >
                                                                <option><?=$veri[0]->grubu?></option>
                                                                <option>son_dakika</option>
                                                                <option>gundem</option>
                                                            </select>

                                                        </div>
                                                    </div>

                                                <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Yetki</label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="Yetki" >
                                                                <option><?=$veri[0]->Yetki?></option>
                                                                <option>Üye</option>
                                                                <option>Admin</option>
                                                                
                                                            </select>

                                                        </div>
                                                </div>

                                               

                                                <div class="form-actions pal">
                                                    <div class="form-group mbn">
                                                        <div class="col-md-offset-3 col-md-6">
                                                            

                                                            <button type="submit" class="btn btn-primary">
                                                                Güncelle</button>

                                                                
                                                        </div>
                                                    </div>
                                                </div>
                                                </form>


                                            </div>
                                        </div>
                    </div>
                </div>
                </div>
            </div>
                      
                <!--END CONTENT-->
<?php 
    $this->load->view('admin/_footer');
?>

<script src="<?=base_url()?>assets/admin/ckeditor/ckeditor.js"></script>
<!--Bootstrap WYSIHTML5 -->
<script src="<?=base_url()?>assets/admin/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script src="<?=base_url()?>assets/admin/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script src="<?=base_url()?>assets/admin/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script>
    $(function (){
        CKEDITOR.replace('aciklama')
        $('.textarea').wysihtml5()
    })
</script>