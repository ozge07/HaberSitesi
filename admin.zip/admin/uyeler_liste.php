 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Üyeler
                        </div>
                        
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Üyeler</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Üyeler Listesi</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                 <div class="panel panel-cream">
                            <div class="panel-heading"><a href="<?=base_url()?>admin/uyeler/ekle" class="btn btn-green navbar-btn"><i class="fa fa-group">
                        <div class="icon-bg bg-violet"></div>
                    </i>Üye Ekle</a><br></div>
                    <?php if ($this->session->flashdata("mesaj")) 
                    { ?>
                        <div class="alert alert-success">
                            <strong><?=$this->session->flashdata("mesaj")?></strong>
                            <a href="#" class="alert-link"></a>
                        </div>
                     <?php
                     }
                    ?>
                            <div class="panel-body">
                                <table class="table table-hover table-bordered">
                                    <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Adı Soyadı</th>
                                        <th>Email</th>
                                        <th>Telefon</th>
                                        <th>Şehir</th>
                                        <th>Yetki</th>
                                        <th>Durum</th>
                                        <th>Düzenle</th>
                                        <th>Sil</th>
                                    </tr>
                                    </thead>

                                    <?php
                                    $sno=0;
                                    foreach($veriler as $rs)
                                    { $sno++;
                                    ?>
                                    <tbody>
                                     <tr>
                                        <td><center><?=$sno?></center></td>
                                        <td><center><?=$rs->adsoy?></center></td>
                                        <td><center><?=$rs->email?></center></td>
                                        <td><center><?=$rs->tel?></center></td>
                                        <td><center><?=$rs->sehir?></center></td>
                                        <td><center><?=$rs->yetki?></center></td>
                                        <td><center><?=$rs->durum?></center></td>
                                        <td><center><a href="<?=base_url()?>admin/uyeler/duzenle/<?=$rs->Id?>"  class="btn btn-blue navbar-btn"><i class="fa fa-edit">&nbsp;&nbsp;</i>Düzenle</a><center></td>
                                        <td><center><a href="<?=base_url()?>admin/uyeler/sil/<?=$rs->Id?>"  onclick="return confirm('Silinsin mi?')"  class="btn btn-red navbar-btn"><i class="fa fa-trash-o">&nbsp;&nbsp;</i>Sil</a></center></td>
                                    </tr>
                                   </tbody>
                                    <?php } ?>
                                </table>
                               
                            </div>
                        </div>  
                    </div>
                </div>
                <!--END CONTENT-->
<?php 
    $this->load->view('admin/_footer');
?>
