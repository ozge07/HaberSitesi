 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
<script src="//cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
           <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Profilim</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Profilim</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Profilim</li>
                    </ol>
                    <div class="clearfix">

                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT--> <?php if ($this->session->flashdata("mesaj")) 
                    { ?>
                        <div class="alert alert-success">
                            <strong><?=$this->session->flashdata("mesaj")?></strong>
                            <a href="#" class="alert-link"></a>
                        </div>
                     <?php
                     }
                    ?>
                <div class="page-content">
                    <div id="tab-general">
                        <div class="row mbl">
                            <div class="col-lg-12">
                                
                                
                                            <div class="col-md-12">

                                                <div id="area-chart-spline" style="width: 100%; height: 300px; display: none; padding: 0px; position: relative;">
                                                <canvas class="flot-base" width="1536" height="375" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 1229px; height: 300px;"></canvas><div class="flot-text" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; font-size: smaller; color: rgb(84, 84, 84);"><div class="flot-x-axis flot-x1-axis xAxis x1Axis" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; display: block;"><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 10px;">Jan</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 212px;">Feb</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 413px;">Mar</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 615px;">Apr</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 816px;">May</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 1018px;">Jun</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 299px; left: 1219px;">Jul</div></div><div class="flot-y-axis flot-y1-axis yAxis y1Axis" style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; display: block;"><div class="flot-tick-label tickLabel" style="position: absolute; top: 290px; left: 1px;">0</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 250px; left: 1px;">25</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 210px; left: 1px;">50</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 170px; left: 1px;">75</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 130px; left: 1px;">100</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 90px; left: 1px;">125</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 50px; left: 1px;">150</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 10px; left: 1px;">175</div></div></div><canvas class="flot-overlay" width="1536" height="375" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 1229px; height: 300px;"></canvas><div class="legend"><div style="position: absolute; width: 0px; height: 0px; top: 15px; right: 15px; background-color: rgb(255, 255, 255); opacity: 0.85;"> </div><table style="position:absolute;top:15px;right:15px;;font-size:smaller;color:#545454"><tbody><tr><td class="legendColorBox"><div style="border:1px solid #ccc;padding:1px"><div style="width:4px;height:0;border:5px solid #ffce54;overflow:hidden"></div></div></td><td class="legendLabel">Upload</td></tr><tr><td class="legendColorBox"><div style="border:1px solid #ccc;padding:1px"><div style="width:4px;height:0;border:5px solid #01b6ad;overflow:hidden"></div></div></td><td class="legendLabel">Download</td></tr></tbody></table></div></div>
                                            </div>
                                
                            </div>


                            <div class="col-lg-12">
                              
                              <form method="post" action="<?=base_url()?>admin/home/myprofile_guncelle/<?=$veri[0]->Id?>" class="form-horizontal">      
                              <div class="row">
                    <div class="col-md-12"><h2><?=$veri[0]->adi?></h2>

                        <div class="row mtl">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <div class="text-center mbl"><img src="<?=base_url()?>uploads/<?=$this->session->admin_session['resim']?>" alt="" class="img-responsive"></div>
                                    
                                </div>
                                <table class="table table-striped table-hover">
                                    <tbody>
                                    <tr>
                                        <td>Adı</td>
                                        <td><?=$veri[0]->adi?></td>
                                    </tr>
                                    <tr>
                                        <td>Email</td>
                                        <td><?=$veri[0]->email?></td>
                                    </tr>
                                    <tr>
                                        <td>Yetki</td>
                                        <td><?=$veri[0]->yetki?></td>              
                                    </tr>
                                    <tr>
                                        <td>Oylama</td>
                                        <td><i class="fa fa-star text-yellow fa-fw"></i><i class="fa fa-star text-yellow fa-fw"></i><i class="fa fa-star text-yellow fa-fw"></i><i class="fa fa-star text-yellow fa-fw"></i><i class="fa fa-star text-yellow fa-fw"></i></td>
                                    </tr>
                                    <tr>
                                        <td>Güncelleme tarihi</td>
                                        <td><?=$veri[0]->tarih?></td>
                                    </tr>
                                    </tbody>
                                </table>
                                <div class="common-modal modal fade" id="common-Modal1" tabindex="-1" role="dialog" aria-hidden="true">
                                    <div class="modal-content">
                                        <ul class="list-inline item-details">
                                            <li><a href="http://themifycloud.com">Admin templates</a></li>
                                            <li><a href="http://themescloud.org">Bootstrap themes</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <ul class="nav nav-tabs">
                                    <li class="active"><a href="#tab-edit" data-toggle="tab">Düzenle</a></li>
                                   
                                </ul>
                                <div id="generalTabContent" class="tab-content">
                                    <div id="tab-edit" class="tab-pane fade in active">
                                        
                                        <form method="post" action="<?=base_url()?>admin/home/myprofile_guncelle/<?=$veri[0]->Id?>" class="form-horizontal">

                                            <h3>Hesap Ayarları</h3>

                                            <div class="form-group"><label class="col-sm-3 control-label">Email</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-9"><input type="email" name="email" placeholder="email" value="<?=$veri[0]->email?>" class="form-control"></div>
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="form-group"><label class="col-sm-3 control-label">Şifre</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-4"><input type="password" name="sifre" placeholder="sifre" value="<?=$veri[0]->sifre?>" class="form-control"></div>
                                                    </div>
                                                </div>
                                            </div>
                                           
                                            <hr>
                                            <h3>Profil Ayarları</h3>

                                            <div class="form-group"><label class="col-sm-3 control-label">Ad</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-9"><input type="text" name="adi" placeholder="adi" value="<?=$veri[0]->adi?>" class="form-control"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                           
                                            <div class="form-group"><label class="col-sm-3 control-label">Doğum Günü</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-4"><input id="datepicker-normal" type="date" name="dgunu" placeholder="dgunu" value="<?=$veri[0]->dgunu?>" class="form-control"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Yetki</label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="yetki" placeholder="Yetki" value="<?=$veri[0]->yetki?>">
                                                                <option><?=$veri[0]->yetki?></option>
                                                                <option>Üye</option>
                                                                <option>Admin</option>
                                                            </select>

                                                        </div>
                                                    </div>



                                            <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Hakkında</label>
                                                        <div class="col-md-9">
                                                            <textarea name="hakkinda" id="editor1"  rows=10 cols=100><?=$veri[0]->hakkinda?></textarea>
                                                            <script>
                                                                 // Replace the <textarea id="editor1"> with a CKEditor
                                                                 // instance, using default configuration.
                                                                  CKEDITOR.replace( 'editor1' );
                                                             </script>
                                                    </div></div>
                                            <hr>
                                            <h3>İletişim Ayarları</h3>

                                            <div class="form-group"><label class="col-sm-3 control-label">Telefon</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-9"><input type="text" name="tel" placeholder="tel" value="<?=$veri[0]->tel?>" class="form-control"></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group"><label class="col-sm-3 control-label">Linkedin</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-9"><input type="text" name="website" placeholder="website" value="<?=$veri[0]->website?>" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group"><label class="col-sm-3 control-label">Facebook</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-9"><input type="text" name="facebook" placeholder="facebook" value="<?=$veri[0]->facebook?>" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group"><label class="col-sm-3 control-label">Twitter</label>

                                                <div class="col-sm-9 controls">
                                                    <div class="row">
                                                        <div class="col-xs-9"><input type="text" name="twitter" placeholder="twitter" value="<?=$veri[0]->twitter?>" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <hr>
                                            <button type="submit" class="btn btn-green btn-block">Güncelle</button>
                                        </form>
                                    </div>
                                    <div id="tab-messages" class="tab-pane fade in">
                                        <div class="row mbl">
                  
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </div>                            
                        </div>
                    </div>
                </div>
                <!--END CONTENT-->
                <!--BEGIN FOOTER-->
                <div id="footer">
                    <div class="copyright">
                        <a href="http://themifycloud.com">2014 © KAdmin Responsive Multi-Purpose Template</a></div>
                </div>
                <!--END FOOTER-->
            </div>
                <!--END CONTENT-->
                <?php 
    $this->load->view('admin/_footer');
?>
