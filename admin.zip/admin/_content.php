 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
            
               
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                           Anasayfa
                        </div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>
                            &nbsp;
                            <a href="<?=base_url()?>admin">Anasayfa</a>
                            &nbsp;&nbsp;
                            <i class="fa fa-angle-right"></i>&nbsp;&nbsp;
                        </li>
                        <li class="hidden">
                            <a href="#">Anasayfa</a>
                            &nbsp;&nbsp;
                            <i class="fa fa-angle-right">    
                            </i>
                            &nbsp;&nbsp;
                        </li>
                        <li class="active">Anasayfa</li>
                    </ol>

                    <div class="clearfix">
                    </div>

            </div><br><br><br><br>
            <center><b><i><h1>Admin Sayfasına Hoşgeldiniz...</h1></i></b></center>
            
                <?php 
    $this->load->view('admin/_footer');
?>
