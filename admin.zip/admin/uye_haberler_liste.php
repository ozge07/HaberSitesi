 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Haberler
                        </div>

                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Haberler</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Haberler Listesi</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                 <div class="panel panel-cream">
                           
                    <?php if ($this->session->flashdata("mesaj"))
                    { ?>
                        <div class="alert alert-success">
                            <strong><?=$this->session->flashdata("mesaj")?></strong>
                            <a href="#" class="alert-link"></a>
                        </div>
                     <?php
                     }
                    ?>
                            <div class="panel-body">
                                <table class="table table-hover table-bordered">
                                    <thead>
                                    <tr>
                                        <th>Nr</th>
                                        <th>Uye Id</th>
                                        <th>Adı</th>
                                        <th>Kategori</th>
                                        <th>Description</th>
                                        <th>Açıklama</th>
                                        <th>Durum</th>
                                        <th>Grubu</th>
                                        <th>Resim</th>
                                        <th>Düzenle</th>
                                        <th>Sil</th>
                                    </tr>
                                    </thead>

                                    <?php
                                    $rn=0;
                                    foreach ($veri as $rs)
                                    { $rn++;
                                    ?>
                                    <tbody>
                                     <tr>
                                        <td><center><?=$rn?></center></td>
                                        <td><center><?=$rs->Id?></center></td>
                                        <td><center><?=$rs->uyeadi?></center></td>
                                        <td><center><?=$rs->katadi?></center></td>
                                        <td><center><?=$rs->description?></center></td>
                                        <td><center><?=$rs->aciklama?></center></td>
                                        <td><center><?=$rs->durum?></center></td>


                                        <td><center><?=$rs->grubu?></center></td>
                                        <td>
                                            <?php if ($rs->resim) { ?>
                                            <a href="<?=base_url()?>admin/uye_haber/resim_yukle/<?=$rs->Id?>" >
                                                <center><img src="<?=base_url()?>uploads/<?=$rs->resim?>" height="30"></center></a>

                                            <?php } else { ?>
                                            <a href="<?=base_url()?>admin/uye_haber/resim_yukle/<?=$rs->Id?>"  class="btn btn-green navbar-btn"><i class="fa fa-edit">&nbsp;&nbsp;</i>Resim yükle</a>
                                            <?php } ?>
                                        </td>
                                        <td><center><a href="<?=base_url()?>admin/uye_haber/haberler_duzenle/<?=$rs->Id?>"  class="btn btn-blue navbar-btn"><i class="fa fa-edit">&nbsp;&nbsp;</i>Düzenle</a><center></td>

                                        <td><center><a href="<?=base_url()?>admin/uye_haber/yayinla/<?=$rs->Id?>" class="btn btn-red navbar-btn"><i class="fa fa-trash-o">&nbsp;&nbsp;</i>Gonder</a></center></td>
                                    </tr>


                                    </tbody>
                                    <?php } ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!--END CONTENT-->
<?php
    $this->load->view('admin/_footer');
?>
