 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
<script src="//cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Haber Ekleme
                          
                        </div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Haber Ekleme</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Haberler Ekleme</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">

                        <div class="panel panel-yellow">
                                            <div class="panel-heading">
                                                Haber Bilgilerini Giriniz
                                            </div>
                                    <div class="panel-body pan">
                                        <form class="form-horizontal" method="post" action="<?=base_url()?>admin/haberler/ekle_kaydet">
                                            <div class="form-body pal">
                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Haber Adı
                                                        </label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="adi" placeholder="Haber Adı" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>

                                            

                                                     <div class="form-group">
                                                        <label for="inputPassword" class="col-md-3 control-label">
                                                            Kategori
                                                        </label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="kategori" >
 
                                                            <?php foreach($kategoriler as $rs) 
                                                            { 
                                                            ?>
                                                                <option value="<?=$rs->Id?>"><?=$rs->adi?></option>
                                                            <?php 
                                                            }
                                                            ?>   
                                                            </select>
                                                           
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Description
                                                        </label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="description" placeholder="Description" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>


                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Açıklama
                                                        </label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <textarea name="aciklama" id="editor1"  rows=10 cols=100>
                                                                </textarea>
                                                                <script>
                                                                  CKEDITOR.replace( 'editor1' );
                                                                </script>
                                                            </div>
                                                        </div>
                                                    </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Keywords
                                                        </label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="keywords" placeholder="Keywords" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Yorum
                                                        </label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="yorum" placeholder="yorum" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Durum
                                                        </label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required       name="durum">
                                                                <option>Onaylandı</option>
                                                                <option>Reddedildi</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Grubu
                                                        </label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required name="grubu">
                                                                <option>son_dakika</option>
                                                                <option>gundem</option>
                                                            </select>

                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Tarih
                                                        </label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="date" name="tarih" placeholder="Tarih" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>

                                                   <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Yetki
                                                        </label>
                                                        <div class="col-md-9">
                                                            <select class="form-control" required       name="yetki">
                                                                <option>Üye</option>
                                                                <option>Admin</option>
                                                            </select>
                                                        </div>
                                                    </div>


                                                </div>

                                                <div class="form-actions pal">
                                                    <div class="form-group mbn">
                                                        <div class="col-md-offset-3 col-md-6">
                                                            <button type="submit" class="btn btn-primary">
                                                                Kaydet
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>

                                            </form>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        

                <!--END CONTENT-->
<?php
    $this->load->view('admin/_footer');
?>
<script src="<?=base_url()?>assets/admin/ckeditor/ckeditor.js"></script>
<!--Bootstrap WYSIHTML5 -->
<script src="<?=base_url()?>assets/admin/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script src="<?=base_url()?>assets/admin/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script src="<?=base_url()?>assets/admin/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script>
    $(function (){
        CKEDITOR.replace('aciklama')
        $('.textarea').wysihtml5()
    })
</script>
