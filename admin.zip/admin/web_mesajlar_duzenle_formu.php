 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
<script src="//cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Mesajlar Düzenleme
                        </div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Mesajlar Düzenleme</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Mesajlar Düzenleme</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">

                        <div class="panel panel-yellow">
                                            <div class="panel-heading">
                                                Mesajınız
                                            </div>
                                            <div class="panel-body pan">

                                                <form class="form-horizontal" method="post" action="<?=base_url()?>admin/web_mesajlar/guncelle/<?=$veri[0]->Id?>">
                                                <div class="form-body pal">

                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Adı Soyadı</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="adsoy" value="<?=$veri[0]->adsoy?>" placeholder="Adı Soyadı" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Email</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="email" name="eposta" value="<?=$veri[0]->email?>" placeholder="Email" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>

                                                     <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Telefon</label>
                                                        <div class="col-md-9">
                                                            <div class="input-icon right">
                                                                <i class="fa fa-user"></i>
                                                                <input id="inputName" required type="text" name="tel" value="<?=$veri[0]->tel?>" placeholder="Telefon" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="inputName" class="col-md-3 control-label">
                                                            Mesaj</label>
                                                        <div class="col-md-9">
                                                            <textarea name="mesaj" id="editor1"  rows=10 cols=100><?=$veri[0]->mesaj?></textarea>
                                                            <script>
                                                                 // Replace the <textarea id="editor1"> with a CKEditor
                                                                 // instance, using default configuration.
                                                                  CKEDITOR.replace( 'editor1' );
                                                             </script>
                                                    </div>
                                                <div class="form-actions pal">
                                                    <div class="form-group mbn">
                                                        <div class="col-md-offset-3 col-md-6">                                                           
                                                            <button type="submit" class="btn btn-primary">
                                                                Güncelle</button>   
                                                        </div>
                                                    </div>
                                                </div>
                                                </form>
                                    </div>
                                </div>
                                </div>
                            </div>
<?php 
    $this->load->view('admin/_footer');
?>
