 <?php
        $this->load->view('admin/_header');
        $this->load->view('admin/_sidebar');
?>
            <!--BEGIN PAGE WRAPPER-->
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                            Haberler
                        </div>

                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="<?=base_url()?>admin">Anasayfa</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Haberler</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Haberler Listesi</li>
                    </ol>
                    <div class="clearfix">
                    </div>
                </div>
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                 <div class="panel panel-cream">
                            <div class="panel-heading"><a href="<?=base_url()?>admin/kategoriler/ekle" class="btn btn-green navbar-btn"><i class="fa fa-group">
                        <div class="icon-bg bg-violet"></div>
                    </i>Yeni Kategori Ekle</a><br>
                            </div>
                    <?php if ($this->session->flashdata("mesaj"))
                    { ?>
                        <div class="alert alert-success">
                            <strong><?=$this->session->flashdata("mesaj")?></strong>
                            <a href="#" class="alert-link"></a>
                        </div>
                     <?php
                     }
                    ?>
                            <div class="panel-body">
                                <table class="table table-hover table-bordered">
                                    <thead>
                                    <tr>
                                        <th>Nr</th>
                                        <th>Kategori</th>
                                        <th>Description</th>
                                        <th>Keywords</th>
                                        <th>Düzenle</th>
                                        <th>Sil</th>
                                    </tr>
                                    </thead>

                                    <?php
                                    $rn=0;
                                    foreach ($kategoriler as $rs)
                                    { $rn++;
                                    ?>
                                    <tbody>
                                     <tr>
                                        <td><center><?=$rn?></center></td>
                                        <td><center><?=$rs->adi?></center></td>
                                        <td><center><?=$rs->description?></center></td>
                                        <td><center><?=$rs->keywords?></center></td>
                                        
                                        <td><center><a href="<?=base_url()?>admin/kategoriler/duzenle/<?=$rs->Id?>"  class="btn btn-blue navbar-btn"><i class="fa fa-edit">&nbsp;&nbsp;</i>Düzenle</a><center></td>
                                        <td><center><a href="<?=base_url()?>admin/kategoriler/sil/<?=$rs->Id?>"  onclick="return confirm('Silinsin mi?')"  class="btn btn-red navbar-btn"><i class="fa fa-trash-o">&nbsp;&nbsp;</i>Sil</a></center></td>
                                    </tr>


                                    </tbody>
                                    <?php } ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!--END CONTENT-->
<?php
    $this->load->view('admin/_footer');
?>
