 <!--BEGIN SIDEBAR MENU-->
            <nav id="sidebar" role="navigation" data-step="2" data-intro="Template has &lt;b&gt;many navigation styles&lt;/b&gt;"
                data-position="right" class="navbar-default navbar-static-side">
            <div class="sidebar-collapse menu-scroll">
                <ul id="side-menu" class="nav">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a  href="<?=base_url()?>admin"?><img height="150" src="<?=base_url()?>assets/images/logos.jpg" alt="" /><br><br>
                    <div class="clearfix"></div></a>

                    <li class="active">
                    <a href="<?=base_url()?>admin">
                    <i class="fa fa-tachometer fa-fw">
                    <div class="icon-bg bg-orange"></div>
                    </i>
                    <span class="menu-title">Anasayfa</span>
                    </a>
                    </li>
                    
                    <li>
                    <a href="<?=base_url()?>admin/uyeler">
                    <i class="fa fa-user">
                    <div class="icon-bg bg-pink"></div>
                    </i>
                    <span class="menu-title">Üyeler</span>
                    </a>
                    </li>

                    <li>
                    <a href="<?=base_url()?>admin/haberler">
                    <i class="fa fa-send-o fa-fw">
                    <div class="icon-bg bg-green"></div>
                    </i><span class="menu-title">Haberler</span>
                    </a>  
                    </li>

                    <li>
                    <a href="<?=base_url()?>admin/Web_mesajlar">
                    <i class="fa fa-send-o fa-fw">
                    <div class="icon-bg bg-green"></div>
                    </i><span class="menu-title">Web Mesajlar</span>
                    </a>  
                    </li>

                    <li>
                    <a href="<?=base_url()?>admin/kategoriler">
                    <i class="fa fa-send-o fa-fw">
                    <div class="icon-bg bg-green"></div>
                    </i><span class="menu-title">Kategoriler</span>
                    </a>  
                    </li>

                    <li>
                    <a href="<?=base_url()?>admin/yorum">
                    <i class="fa fa-send-o fa-fw">
                    <div class="icon-bg bg-green"></div>
                    </i><span class="menu-title">Yorumlar</span>
                    </a>  
                    </li>

                    <li>
                    <a href="<?=base_url()?>admin/uye_haber">
                    <i class="fa fa-send-o fa-fw">
                    <div class="icon-bg bg-green"></div>
                    </i><span class="menu-title">Üye Haberleri</span>
                    </a>  
                    </li>

                    <li>
                    <a href="<?=base_url()?>admin/uye_haber/listele/onaylandi">
                    <i class="fa fa-send-o fa-fw">
                    <div class="icon-bg bg-green"></div>
                    </i><span class="menu-title">Onaylanan Üye Haberleri</span>
                    </a>  
                    </li>

                    <li>
                    <a href="<?=base_url()?>admin/uye_haber/listele/reddedildi">
                    <i class="fa fa-send-o fa-fw">
                    <div class="icon-bg bg-green"></div>
                    </i><span class="menu-title">Reddedilen Üye Haberleri</span>
                    </a>  
                    </li>
                       
                </ul>
                

<form action="https://www.google.com/search" method="GET" target="_blank" style="height:250px" id="kd-google-search-cust-log">
<div class="kd-g-s-c-l-imghold">
<img alt="Google Logo" src="https://4.bp.blogspot.com/-tn5-DcRLsUo/V9bnYzVYf6I/AAAAAAAA790/MthDMZG0PtsrYQPNmdn7TeYxTZFhAAYngCLcB/s1600/koddostu-google.png">
</div>
<input type="text" name="q" class="kd-g-s-c-l-input">
<input value="Google'da Ara" class="kd-g-s-c-l-submit" type="submit">
</form>
<script src="https://www.koddostu.com/kdjs/arama.js"></script>
<script src="https://www.koddostu.com/duzelt.js?no=367"></script>



<input type="checkbox" id="kdfab1535" class="kdpfab"/>
<div class="koddostu-com-paylas yuvarlak">
<a href="#" class="koddostu-paylas kd-facebook"></a>
<a href="#" class="koddostu-paylas kd-twitter"></a>
<a href="#" class="koddostu-paylas kd-pinterest"></a>
<a href="#" class="koddostu-paylas kd-whatsapp"></a>
<a href="#" class="koddostu-paylas kd-linkedin"></a>
<a href="#" class="koddostu-paylas kd-mail"></a>
<a href="#" class="koddostu-paylas kd-tumblr"></a>
<a href="#" class="koddostu-paylas kd-blogger"></a>
<a href="#" class="koddostu-paylas kd-googleplus"></a>
<a href="#" class="koddostu-paylas kd-vkontakte"></a>
<a href="#" class="koddostu-paylas kd-evernote"></a>

</div>
<script>
(function () {
var a=document.createElement("link"); a.type="text/css";a.rel="stylesheet"; a.href="http://panel.koddostu.com/css/2.css";
a.media="all";document.getElementsByTagName("head")[0].appendChild(a);}());
</script>
<script charset="iso-8859-9" type="text/javascript" src="http://www.koddostu.com/kdjs/dmca/koddostu-com-paylas.js?90"></script>
<script src="https://www.koddostu.com/duzelt.js?no=344"></script>


   </div>
     </nav>
        </div>
          </nav>
 
